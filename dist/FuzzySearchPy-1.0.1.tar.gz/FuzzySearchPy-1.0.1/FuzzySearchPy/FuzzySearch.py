from .Helper import getDescendantProperty

class FuzzySearch:
    def __init__(self, haystack = None, keys = None, options = None):
        self.haystack = haystack if haystack != None else []
        self.keys = keys if keys != None else []
        if options == None:
            options = {}
        if not "caseSensitive" in options:
            options["caseSensitive"] = False
        if not "sort" in options:
            options["sort"] = False
        self.options = options
    
    def search(self, query = ""):
        if query == None or len(query) <= 0:
            return self.haystack
        
        results = []

        for item in self.haystack:
            print("item in search", item)
            if len(self.keys) <= 0:
                score = FuzzySearch.isMatch(item, query, self.options["caseSensitive"])
                if score != False:
                    results.append(( item, score ))
            else:
                for key in self.keys:
                    print("key", key, item)
                    propertyValues = getDescendantProperty(item, key)
                    found = False

                    for propertyValue in propertyValues:
                        print("prop value", propertyValue, item)
                        score = FuzzySearch.isMatch(propertyValue, query, self.options["caseSensitive"])

                        if score != False:
                            found = True
                            results.append(( item, score ))
                            break
                    
                    if found:
                        break
            
        if self.options["sort"]:
            print("will sort", results)
            results.sort(key=lambda thing : thing[1])

        return [result[0] for result in results]
    
    @staticmethod
    def isMatch(item, query, caseSensitive):
        item = str(item)
        query = str(query)

        if not caseSensitive:
            item = item.lower()
            query = query.lower()
        print("item in is match", item)
        
        indicies = FuzzySearch.nearestIndexFor(item, query)
        print("indicies in is match", indicies)
        if indicies == None:
            return False
        
        if item == query:
            return 1
        
        if len(indicies) > 1:
            return 2 + indicies[-1] - indicies[0]
        
        return 2 + indicies[0]
    
    @staticmethod
    def nearestIndexFor(item, query):
        print("item in nearest index for", item)
        letters = [letter for letter in query]
        
        indiciesOfFirstLetter = FuzzySearch.getIndiciesOfFirstLetter(item, query)
        print("letter ind", indiciesOfFirstLetter)
        indiciesLength = len(indiciesOfFirstLetter)
        # init the array
        indicies = [None] * indiciesLength
        
        for loopingIndex in range(indiciesLength):
            startingIndex = indiciesOfFirstLetter[loopingIndex]
            index = startingIndex
            indicies[loopingIndex] = [startingIndex]

            for letter in letters:
                try:
                    index = item.index(letter, index)
                    print("this index", letter, index)
                    indicies[loopingIndex].append(index)
                    index += 1
                except ValueError:
                    indicies[loopingIndex] = None
                    break
            print("indicies", indicies)
        
        indicies = list(filter(lambda thing : thing != None, indicies))
        
        if len(indicies) <= 0:
            return None

        indicies.sort(key=lambda thing : thing[0] if len(thing) == 1 else thing[-1] - thing[0])

        return indicies[0]
    
    @staticmethod
    def getIndiciesOfFirstLetter(item, query):
        match = query[0]

        letters = [char for char in item]
        letterLength = len(letters)

        preFilter = [None] * letterLength

        for index in range(letterLength):
            if letters[index] == match:
                preFilter[index] = index
        return list(filter(lambda thing : thing != None, preFilter))